=== Custom Post Text ===
Contributors: Ronnie268
Donate link: http://jjtcomputing.co.uk/blog/donate/
Tags: post, custom, text, footer, header, every
Requires at least: 2.0
Tested up to: 2.7.1
Stable tag: 1.0

This plugin is for adding certain text to every post, before or after.

== Description ==

This plugin is for adding certain text to every post, before or after.

* Example : You can add a copyright notice to each post, or licensce information


**For Example and Details Visit :** [http://www.jjtcomputing.co.uk/](http://www.jjtcomputing.co.uk/ "Examples and Details")

**My Technical Blog is :** [http://www.jjtcomputing.co.uk/blog](http://www.jjtcomputing.co.uk/blog/ "My Technical Blog")

== Installation ==

1. Unzip the files 
1. Upload custom-post-text directory (containing custom-post-text.php file) to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

OR

1. Locate it using the Plugin browser function
1. Click Install
1. On the "Success!" screen, click Activate.

== Frequently Asked Questions ==

= Should i edit any files? =

No, just activate the plugin.

== Screenshots ==

1. The plugin in use at jjtcomputing.co.uk/blog/

== Other Notes ==

If you have any queires / complaints regarding this plugin, please feel free to mail me at webmaster@jjtcomputing.co.uk. Thank you

See my blog for  updates [http://www.jjtcomputing.co.uk/blog/](http://www.jjtcomputing.co.uk/blog/ "Blog") .